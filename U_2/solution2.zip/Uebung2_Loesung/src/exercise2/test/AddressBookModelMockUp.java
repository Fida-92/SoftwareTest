/*
 * Example code used in exercises for lecture "Grundlagen des Software-Testens"
 * Created and given by Ina Schieferdecker and Edzard Hoefig
 * Freie Universitaet Berlin, SS 2013
 */
package exercise2.test;

import java.io.IOException;
import java.util.Collection;

import exercise2.addressbook.model.AddressBookModel;
import exercise2.addressbook.model.Entry;
import exercise2.addressbook.model.SizeLimitReachedException;

/**
 * Uebung 2 - Komponenten und Integrationstest
 * Mock-Up für das AddressBookModel
 * 
 * Bitte Nummer der Gruppe eintragen:
 * 0
 * 
 * Bitte Gruppenmitglieder eintragen:
 * @author Edzard Hoefig
 * @author Theo Vassiliou
 */
public class AddressBookModelMockUp implements AddressBookModel {

	// Holds the last entry made
	private Entry lastEntry;
	
	// Used to simulate that the address book is full
	private boolean full;
	
	@Override
	public boolean addEntry(Entry entry) throws SizeLimitReachedException {
		System.out.println("add");
		if (full) throw new SizeLimitReachedException("Address book is full");
		lastEntry = entry;
		return true;
	}

	@Override
	public Entry getEntry(String surName, String firstName) {
		System.out.println("get");
		return null;
	}

	@Override
	public Collection<Entry> getEntries() {
		System.out.println("get*");
		return null;
	}

	@Override
	public boolean deleteEntry(Entry entry) {
		System.out.println("del");
		return true;
	}

	@Override
	public void erase() {
		System.out.println("erase");
	}

	@Override
	public void load() throws IOException {
		System.out.println("load");
	}

	@Override
	public void save() throws IOException {
		System.out.println("save");
	}

	/**
	 * Instrumentation: Forgets the last entry.
	 */
	public void clearLastEntry() {
		this.lastEntry = null;
	}

	public Entry getLastEntry() {
		return this.lastEntry;
	}
	
	/**
	 * Instrumentation: Instructs the mock-up to deny every addEntry method invocation with a SizeLimitReachedException.
	 */
	public void setFull() {
		this.full = true;	
	}
}

