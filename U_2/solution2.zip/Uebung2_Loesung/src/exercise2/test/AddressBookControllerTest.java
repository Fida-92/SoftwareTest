/*
 * Example code used in exercises for lecture "Grundlagen des Software-Testens"
 * Created and given by Ina Schieferdecker, Theo Vassiliou and Julia Martini
 * Technische Universität Berlin
 */
package exercise2.test;

import static exercise2.addressbook.model.Gender.Female;
import static exercise2.addressbook.model.Gender.Male;
import static exercise2.test.AssertHelper.assertEntry;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import exercise2.addressbook.controller.AddressBookController;
import exercise2.addressbook.controller.AddressBookControllerImpl;
import exercise2.addressbook.controller.ParameterException;
import exercise2.addressbook.model.EmailAddress;
import exercise2.addressbook.model.PhoneNumber;
import exercise2.addressbook.model.SizeLimitReachedException;

/**
 * Uebung 2 - Komponenten und Integrationstest
 * Komponententests für den Controller
 * 
 * Bitte Nummer der Gruppe eintragen:
 * 0
 * 
 * Bitte Gruppenmitglieder eintragen:
 * @author Edzard Hoefig
 * @author Theo Vassiliou
 */
public class AddressBookControllerTest {
	
	/*
	 *  Aufgabe 3
	 *  Führen Sie im Rahmen eines Komponententests der Klasse exercise2.addressbook.controller.AddressBookController einen Test der Methode add(...) durch.
	 *  Schreiben Sie für die model und view Komponenten Mock-Up Klassen und verwenden Sie dies im Komponententest der AddressBookController Komponente.
	 *  Testen Sie die add() Methode auf Herz und Nieren - es sind durchaus Fehler zu finden.
	 */
	
	// Model component for the test
	AddressBookModelMockUp model;
	
	// View component for the test
	AddressBookViewMockUp view;
	
	// Controller component for the test
	AddressBookController controller;
	
	/**
	 * Set up test system
	 */
	@Before
	public void setUp() {
		// Instantiate and wire components
		this.model = new AddressBookModelMockUp();
		this.view = new AddressBookViewMockUp();
		this.controller = new AddressBookControllerImpl(model, view);
	}
	
	/**
	 * Test normal cases
	 * @throws Exception If the SUT fails
	 */
	@Test
	public void testAddNormal() throws Exception {

		this.controller.add("Donald", "Duck", "M", "112", null);
		assertEntry("Donald", "Duck", Male, new PhoneNumber(112), this.model.getLastEntry());
		this.model.clearLastEntry();
		
		this.controller.add("Donald", "Duck", "M", null, "foo@bar.com");
		assertEntry("Donald", "Duck", Male, new EmailAddress("foo@bar.com"), this.model.getLastEntry());
		this.model.clearLastEntry();
		
		this.controller.add("Daisy", "Duck", "F", "112", null);
		assertEntry("Daisy", "Duck", Female, new PhoneNumber(112), this.model.getLastEntry());
		this.model.clearLastEntry();
		
		this.controller.add("Daisy", "Duck", "F", null, "foo@bar.com");
		assertEntry("Daisy", "Duck", Female, new EmailAddress("foo@bar.com"), this.model.getLastEntry());
		this.model.clearLastEntry();
	}
	
	/**
	 * Test missing first name
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testNoFirstName() throws SizeLimitReachedException {
		try {
			this.controller.add(null, "Duck", "M", "112", null);
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test missing last name
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testNoLastName() throws SizeLimitReachedException {
		try {
			this.controller.add("Donald", null, "M", "112", null);
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test double contact information
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testAddWithTwoContacts() throws SizeLimitReachedException {
		try {
			this.controller.add("Donald", "Duck", "M", "112", "foo@bar.com");
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test no contact information
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testAddWithNoContacts() throws SizeLimitReachedException {
		try {
			this.controller.add("Donald", "Duck", "M", null, null);
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test incorrect gender parameter
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testAddWithStrangeGender()  throws SizeLimitReachedException {
		try {
			this.controller.add("Dr.", "Frank-N-Furter", "?", "112", null);
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test missing gender parameter
	 * @throws SizeLimitReachedException If the SUT fails
	 */
	@Test
	public void testAddWithNoGender() throws SizeLimitReachedException {
		try {
			this.controller.add("Dr.", "Frank-N-Furter", null, "112", null);
			fail();
		} catch (ParameterException ex) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
	
	/**
	 * Test controller behavior when address book is full
	 */
	@Test
	public void testAddWhileAddressBookFull(){
		try {
			this.model.setFull();
			this.controller.add("Donald", "Duck", "M", "112", null);
			fail();
		} catch (ParameterException ex) {
			fail();
		} catch (SizeLimitReachedException e) {
			// ok
		}
		assertNull(this.model.getLastEntry());
	}
}
