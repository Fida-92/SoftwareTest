/*
 * Example code used in exercises for lecture "Grundlagen des Software-Testens"
 * Created and given by Ina Schieferdecker, Theo Vassiliou and Julia Martini
 * Technische Universität Berlin
 */
package exercise2.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import exercise2.addressbook.model.Contact;
import exercise2.addressbook.model.EmailAddress;
import exercise2.addressbook.model.Entry;
import exercise2.addressbook.model.Gender;
import exercise2.addressbook.model.PhoneNumber;

/**
 * Uebung 2 - Komponenten und Integrationstest
 * Zusätzliche assert Anweisungen
 * 
 * Bitte Nummer der Gruppe eintragen:
 * 0
 * 
 * Bitte Gruppenmitglieder eintragen:
 * @author Edzard Hoefig
 * @author Theo Vassiliou
 */
public class AssertHelper {

	/**
	 * Instrumentation: Checks the given entry data against an actual entry from the address book.
	 * @param firstName the expected first name
	 * @param lastName the expected surname
	 * @param gender the expected gender
	 * @param contact the expected contact information
	 * @param entry The actual entry
	 */
	public static void assertEntry(String firstName, String lastName, Gender gender, Contact contact, Entry entry) {
		assertNotNull(entry);
		assertEquals(firstName, entry.getFirstName());
		assertEquals(lastName, entry.getSurName());
		switch (gender) {
		case Male:
			assertTrue(entry.isMale());
			break;
		case Female:
			assertTrue(entry.isFemale());
			break;
		default:
			fail();
		}
		if (contact instanceof PhoneNumber) {
			assertTrue(entry.getContactInformation() instanceof PhoneNumber);
			final PhoneNumber phone = (PhoneNumber)entry.getContactInformation();
			assertTrue(phone.getNumber() >= 0);
			assertEquals(((PhoneNumber)contact).getNumber(), phone.getNumber());
		} else if (contact instanceof EmailAddress) {
			assertTrue(entry.getContactInformation() instanceof EmailAddress);
			final EmailAddress address = (EmailAddress)entry.getContactInformation();
			assertEquals(((EmailAddress)contact).getEmailAddress(), address.getEmailAddress());
		} else {
			fail();
		}
	}
	
}
