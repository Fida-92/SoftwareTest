/*
 * Example code used in exercises for lecture "Grundlagen des Software-Testens"
 * Created and given by Ina Schieferdecker, Theo Vassiliou and Julia Martini
 * Technische Universität Berlin
 */

package exercise2.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Uebung 2 - Komponenten und Integrationstest
 * TestSuite
 * 
 * Bitte Nummer der Gruppe eintragen:
 * 0
 * 
 * Bitte Gruppenmitglieder eintragen:
 * @author Edzard Hoefig
 * @author ...
 */
@RunWith(Suite.class)
@SuiteClasses({ AddressBookControllerTest.class,
		ControllerAddressBookIntegrationTest.class })
public class AllTests {
	/*
	 * Aufgabe 5
	 * Erstellen Sie eine JUnit TestSuite mit der Komponenten- und Integrationstest automatisch ausgefuehrt werden koennen
	 */
}
