/*
 * Example code used in exercises for lecture "Grundlagen des Software-Testens"
 * Created and given by Ina Schieferdecker, Theo Vassiliou and Julia Martini
 * Technische Universität Berlin
 */
package exercise2.test;

import static exercise2.addressbook.model.Gender.Female;
import static exercise2.addressbook.model.Gender.Male;
import static exercise2.test.AssertHelper.assertEntry;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.Vector;

import org.junit.Before;
import org.junit.Test;

import exercise2.addressbook.controller.AddressBookController;
import exercise2.addressbook.controller.AddressBookControllerImpl;
import exercise2.addressbook.controller.ParameterException;
import exercise2.addressbook.model.AddressBookModel;
import exercise2.addressbook.model.AddressBookModelImpl;
import exercise2.addressbook.model.EmailAddress;
import exercise2.addressbook.model.Entry;
import exercise2.addressbook.model.PhoneNumber;
import exercise2.addressbook.model.SizeLimitReachedException;

/**
 * Uebung 2 - Komponenten und Integrationstest
 * Integration Test für Addressbook und Controller.
 * 
 * Bitte Nummer der Gruppe eintragen:
 * 0
 * 
 * Bitte Gruppenmitglieder eintragen:
 * @author Edzard Hoefig
 * @author ...
 */
public class ControllerAddressBookIntegrationTest {

	// Location of the address book file
	private static final File addressBookFile = new File("contacts.xml");
		
	/*
	 *  Aufgabe 4
	 *  Programmieren Sie einen Integrationstest für AddressBookModel und AddressBookController.
	 *  Testen Sie ob die Methoden des exercise2.addressbook.controller.AddressBookController Interface zu den erwarteten Resultate im Addressbuch führen.
	 *  Testen Sie intensiv und schreiben Sie MINDESTENS einen Testfall pro Methode des interfaces. Es sind Fehler zu finden.  
	 */
	
	// Model component for the test
	AddressBookModel model;
	
	// View component for the test
	AddressBookViewMockUp view;
	
	// Controller component for the test
	AddressBookController controller;
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		// Instantiate and wire components
		this.model = new AddressBookModelImpl(addressBookFile);
		this.view = new AddressBookViewMockUp();
		this.controller = new AddressBookControllerImpl(model, view);
	}

	@Test
	public void testAddEntries() throws Exception {
		
		// Normal adding of entries (all combinations)
		this.controller.add("Donald", "Duck", "M", "112", null);
		this.controller.add("Dagobert", "Duck", "M", null, "dago@bertie.com");
		this.controller.add("Daisy", "Duck", "F", "110", null);
		this.controller.add("Dorette", "Duck", "F", null, "dori@entenhausen.de");
		
		final Vector<Entry> entries = new Vector<Entry>(this.model.getEntries());
		assertEquals(4, this.model.getEntries().size());
		assertEntry("Dagobert", "Duck", Male, new EmailAddress("dago@bertie.com"), entries.get(0));
		assertEntry("Daisy", "Duck", Female, new PhoneNumber(110), entries.get(1));
		assertEntry("Donald", "Duck", Male, new PhoneNumber(112), entries.get(2));
		assertEntry("Dorette", "Duck", Female, new EmailAddress("dori@entenhausen.de"), entries.get(3));
	}
	
	@Test
	public void testSizeLimit() {
		
		// Fill up address book until at size limit
		for (int i=0; i < AddressBookModelImpl.sizeLimit; ++i) {
			try {
				this.controller.add("first" + i, "last" + i, i%2 == 0? "M" : "F", Integer.toString(i), null);
			} catch (Exception e) {
				fail();
			}
		}
		
		// Assert entries
		final Vector<Entry> entries = new Vector<Entry>(this.model.getEntries());
		assertEquals(AddressBookModelImpl.sizeLimit, this.model.getEntries().size());
		for (int i=0; i < AddressBookModelImpl.sizeLimit; ++i) {
			assertEntry("first" + i, "last" + i, i%2 == 0? Male : Female, new PhoneNumber(i), entries.get(i));
		}
		
		// Assert throwing of exception
		try {
			this.controller.add("Donald", "Duck", "M", "112", null);
			fail();
		} catch (SizeLimitReachedException ex) {
			// ok
		} catch (ParameterException ex2) {
			fail();
		}
	}
	
	@Test
	public void testEraseEntry() throws Exception {
		
		// Add two entries
		this.controller.add("Gustav", "Gans", "M", "999", null);
		this.controller.add("Dagobert", "Duck", "M", null, "dago@bertie.com");
				
		// Check last entry removal
		this.controller.remove(1);
		final Vector<Entry> entries = new Vector<Entry>(this.model.getEntries());
		assertEquals(1, this.model.getEntries().size());
		assertEntry("Dagobert", "Duck", Male, new EmailAddress("dago@bertie.com"), entries.get(0));
		
		// Check final entry removal
		this.controller.remove(0);
		assertEquals(0, this.model.getEntries().size());
	}

	@Test
	public void testEraseAllEntries() throws Exception {
		// Add two entries
		this.controller.add("Gustav", "Gans", "M", "999", null);
		this.controller.add("Dagobert", "Duck", "M", null, "dago@bertie.com");
		
		// Check clear functionality
		this.controller.erase();
		assertEquals(0, this.model.getEntries().size());
	}
}
